import { useState, useEffect } from "react";

const SECTIONS = [
  {
    id: "s1", icon: "📋", title: "事前確認・受付", color: "#3B82F6",
    items: [
      { id: "1-1",  text: "氏名・住所・生年月日の確認（住民票・マイナンバーカードと照合）", critical: true,  tip: "本人確認書類と必ず突合。転居・氏名変更は別途手続きも確認" },
      { id: "1-2",  text: "マイナンバーの確認・記録（12桁）", critical: true,  tip: "記録保管ルールを遵守。コピー保管は法令で認められた範囲内で" },
      { id: "1-3",  text: "世帯構成の変更確認（結婚・離婚・出生・死亡）", critical: false, tip: "扶養関係・配偶者控除に直結。ヒアリングシートで確認" },
      { id: "1-4",  text: "昨年からの変更事項（転職・廃業・不動産売買等）", critical: false, tip: "「変わったことは？」だけでなく、具体的な場面を想定した質問を" },
      { id: "1-5",  text: "過年度申告との整合性確認", critical: false, tip: "前年比較で大きな変動がある項目を重点確認" },
      { id: "1-6",  text: "源泉徴収票が全雇用先分揃っているか", critical: true,  tip: "副業・アルバイト含め全勤務先分を確認" },
      { id: "1-7",  text: "支払調書（報酬等）が揃っているか", critical: false, tip: "5万円超の支払は原則発行義務あり" },
      { id: "1-8",  text: "医療費領収書または医療費通知書の有無", critical: false, tip: "セルフメディケーション税制との選択も確認" },
      { id: "1-9",  text: "各種控除証明書の有無（生命保険・地震保険・社会保険等）", critical: false, tip: "年金機構等からの証明書も忘れずに" },
      { id: "1-10", text: "資料受取チェックリストとの照合完了", critical: false, tip: "「もらったつもり」が最大のリスク" },
      { id: "1-11", text: "依頼者へのヒアリングシートの返却・未回答欄の確認", critical: false, tip: "ヒアリングシートの未回答欄がないか確認" },
      { id: "1-12", text: "申告種別の確認（白色・青色・初回申告・修正申告等）", critical: true,  tip: "初回の場合は青色申告承認申請書の提出状況も確認" },
      { id: "1-13", text: "e-Tax利用者識別番号・暗証番号の確認", critical: false, tip: "e-Tax送信前に必ず確認。有効期限切れに注意" },
      { id: "1-14", text: "委任状・委任関係の確認（代理申告の場合）", critical: true,  tip: "代理人申告は委任状が必要。内容を依頼者に確認済みか" },
    ]
  },
  {
    id: "s2", icon: "💰", title: "収入の確認", color: "#10B981",
    items: [
      { id: "2-1",  text: "全源泉徴収票の給与収入を合算", critical: true,  tip: "複数勤務先がある場合は全票を合計" },
      { id: "2-2",  text: "源泉徴収票の内容と申告書の整合性確認", critical: true,  tip: "給与所得控除後の金額・源泉税額を正確に転記" },
      { id: "2-3",  text: "給与と退職所得の区分（退職所得は分離課税）", critical: true,  tip: "退職所得控除の計算。勤続年数・障害者退職等の確認も必須" },
      { id: "2-4",  text: "収支内訳書または青色申告決算書の添付", critical: true,  tip: "青色申告特別控除の適用要件（65万・55万・10万）を確認" },
      { id: "2-5",  text: "売上計上漏れがないか（現金売上・口座以外の収入も）", critical: true,  tip: "物々交換・デジタル通貨・物品受取も収入に含まれる" },
      { id: "2-6",  text: "必要経費の家事按分が適正か", critical: true,  tip: "按分基準の合理性と証拠書類を確認" },
      { id: "2-7",  text: "青色申告65万控除の要件（e-Tax申告または電子帳簿保存）", critical: true,  tip: "令和3年分以降は必須要件。書面申告は55万円" },
      { id: "2-8",  text: "不動産所得：減価償却の計算", critical: true,  tip: "耐用年数・未償却残高・法定償却方法を確認" },
      { id: "2-9",  text: "不動産所得：土地取得借入金利子の損益通算制限", critical: true,  tip: "土地取得対応部分の借入利子は損益通算不可" },
      { id: "2-10", text: "消費税の処理（免税・課税・インボイス対応）", critical: true,  tip: "消費税申告との整合性確認。インボイス登録番号の確認も" },
      { id: "2-11", text: "株式等の譲渡（特定口座・一般口座の区分）", critical: true,  tip: "源泉徴収あり→申告不要選択可否を確認" },
      { id: "2-12", text: "上場株式等の譲渡損失の繰越控除（前年以前3年分）", critical: true,  tip: "前年申告書の付表3との照合" },
      { id: "2-13", text: "不動産の譲渡（長期・短期の区分）", critical: true,  tip: "所有期間5年超で長期。売却年の1/1基準で判定" },
      { id: "2-14", text: "居住用財産の3,000万円特別控除の要件確認", critical: true,  tip: "住んでいた家屋の売却か。住まなくなった日から3年後の12/31まで" },
      { id: "2-15", text: "相続空き家の3,000万円特別控除（令和6年改正後）", critical: true,  tip: "令和6年以降は2億円上限・耐震または取壊し等の要件変更あり" },
      { id: "2-16", text: "取得費・譲渡費用の計算（概算5%と実額の有利判定）", critical: true,  tip: "取得費不明の場合は概算5%。証明書類がある場合は実額と比較" },
      { id: "2-17", text: "公的年金等の雑所得（令和2年改正後の控除額）", critical: false, tip: "65歳以上・65歳未満で控除額が異なる" },
      { id: "2-18", text: "副業・業務にかかる雑所得（300万円超は記帳義務）", critical: true,  tip: "300万円超は帳簿保存要件の確認" },
      { id: "2-19", text: "暗号資産（仮想通貨）の損益計算", critical: true,  tip: "移動平均法が原則。総平均法選択届出の確認" },
      { id: "2-20", text: "配当所得の申告有利・不利判定（総合/分離/不申告の3択）", critical: true,  tip: "課税所得によって最適な申告方法が異なる。必ず試算" },
      { id: "2-21", text: "事業所得と雑所得の区分（副業の判定）", critical: true,  tip: "社会通念上の事業性・継続性・規模等で判断" },
      { id: "2-22", text: "山林所得・一時所得（満期保険・競馬等）の計上", critical: false, tip: "一時所得は収入－支出－50万円の1/2を総所得に加算" },
      { id: "2-23", text: "非課税所得の混入がないか（通勤手当・傷病手当等）", critical: true,  tip: "非課税所得を課税所得に含めていないか確認" },
      { id: "2-24", text: "海外赴任・二重課税となる所得の確認", critical: false, tip: "非居住者期間は課税関係が異なる。外国税額控除との関係も" },
    ]
  },
  {
    id: "s3", icon: "🛡️", title: "所得控除の確認", color: "#8B5CF6",
    items: [
      { id: "3-1",  text: "国民年金・国民健康保険料の確認（証明書または領収書）", critical: false, tip: "退職後の任意継続健康保険料も忘れずに" },
      { id: "3-2",  text: "iDeCo・国民年金基金の掛金（証明書と照合）", critical: false, tip: "全額所得控除対象。節税効果が大きい" },
      { id: "3-3",  text: "家族分の社会保険料を本人が支払っている場合の計上", critical: true,  tip: "生計一親族の社会保険料は本人の控除対象" },
      { id: "3-4",  text: "旧制度・新制度の区分が正しいか（平成24年1月1日以後=新制度）", critical: false, tip: "上限額が異なる。旧：5万・新：4万（各区分）" },
      { id: "3-5",  text: "介護医療保険料（新制度3区分）の計上漏れがないか", critical: false, tip: "一般・介護医療・個人年金の3区分。各上限4万円" },
      { id: "3-6",  text: "地震保険料と旧長期損害保険料の区分", critical: false, tip: "地震：最大5万円。旧長期：最大1万5千円" },
      { id: "3-7",  text: "医療費控除とセルフメディケーション税制の有利選択", critical: true,  tip: "両方同時適用不可。必ず試算して選択" },
      { id: "3-8",  text: "医療費控除の対象外費用が含まれていないか", critical: true,  tip: "美容整形・予防接種・健診（疾患発見後を除く）は原則対象外" },
      { id: "3-9",  text: "通院交通費の計上漏れがないか（電車・バスは実費）", critical: false, tip: "タクシーは緊急時のみ対象" },
      { id: "3-10", text: "保険金・高額療養費で補填される金額を医療費から控除", critical: true,  tip: "補填金額を忘れずに差し引く" },
      { id: "3-11", text: "ふるさと納税：ワンストップ特例との選択確認", critical: true,  tip: "確定申告する場合はワンストップ無効→寄附金控除で申告" },
      { id: "3-12", text: "ふるさと納税の上限額との乖離確認", critical: true,  tip: "上限超過分は控除不可。上限額試算と比較" },
      { id: "3-13", text: "配偶者の合計所得が133万円以下か（配偶者特別控除含む）", critical: true,  tip: "配偶者控除：48万以下　特別控除：48万超133万以下" },
      { id: "3-14", text: "本人の合計所得が1,000万円以下か（配偶者控除の要件）", critical: true,  tip: "1,000万超は配偶者控除・特別控除いずれも適用不可" },
      { id: "3-15", text: "扶養親族の年齢区分確認（16歳未満・特定扶養・老人扶養）", critical: true,  tip: "特定扶養（19〜22歳）=63万円、老人扶養（70歳以上）=48or58万円" },
      { id: "3-16", text: "扶養親族の合計所得が48万円以下か", critical: true,  tip: "給与収入のみなら103万円以下が目安" },
      { id: "3-17", text: "同居老親等の確認（同居58万・別居48万）", critical: false, tip: "生計一であれば別居でも老人扶養控除対象" },
      { id: "3-18", text: "障害者控除の適用漏れがないか（特別障害者75万円）", critical: true,  tip: "精神・身体・療育手帳保持者。毎年必ずヒアリング" },
      { id: "3-19", text: "ひとり親控除・寡婦控除の適用確認", critical: true,  tip: "令和2年改正。合計所得500万円以下の要件確認" },
      { id: "3-20", text: "扶養の重複がないか（他の納税者との照合）", critical: true,  tip: "同一人物を複数の申告書で扶養に入れていないか" },
      { id: "3-21", text: "基礎控除48万円（所得2,400万円超は逓減）", critical: true,  tip: "高所得者は基礎控除が減額または0になる" },
      { id: "3-22", text: "雑損控除（災害・盗難・横領）の計上", critical: false, tip: "損失額から保険金等を差し引き。繰越控除3年間" },
      { id: "3-23", text: "小規模企業共済等掛金控除（iDeCo・企業型DC等）の確認", critical: false, tip: "証明書の金額と申告額を照合" },
      { id: "3-24", text: "勤労学生控除の適用確認", critical: false, tip: "合計所得75万円以下の学生・生徒が対象" },
      { id: "3-25", text: "特定支出控除の要否確認（給与所得者）", critical: false, tip: "給与所得控除の1/2超の特定支出がある場合のみ。証明書類必要" },
    ]
  },
  {
    id: "s4", icon: "🏠", title: "税額控除の確認", color: "#F59E0B",
    items: [
      { id: "4-1",  text: "住宅ローン控除：適用年数・残高限度額（取得時期・種別による差異）", critical: true,  tip: "令和4年以降の改正内容（新築・既存・増改築）を確認" },
      { id: "4-2",  text: "年末残高証明書の金額と申告額の照合", critical: true,  tip: "複数ローンがある場合はすべて合算" },
      { id: "4-3",  text: "初年度：確定申告が必須（年末調整不可）", critical: true,  tip: "2年目以降は年末調整対応可能" },
      { id: "4-4",  text: "床面積・入居要件の確認（50㎡以上、一定要件で40㎡以上）", critical: false, tip: "入居後6か月以内の要件も確認" },
      { id: "4-5",  text: "居住用割合が100%か（事業兼用の場合は按分）", critical: true,  tip: "事業用部分は住宅ローン控除対象外" },
      { id: "4-6",  text: "住宅ローン控除の適用期間終了確認（終了済なら該当なし）", critical: false, tip: "10年・13年・各年数の切れに注意" },
      { id: "4-7",  text: "外国税額控除（外国株式の配当源泉税等）", critical: false, tip: "外国で課税された所得・税額の計算確認" },
      { id: "4-8",  text: "政党等寄附金特別控除（寄附金控除との有利選択）", critical: false, tip: "税額控除と所得控除、どちらが有利か試算" },
      { id: "4-9",  text: "認定NPO法人等への寄附金特別控除の確認", critical: false, tip: "所得控除か税額控除かを選択できる。有利判定必須" },
      { id: "4-10", text: "試験研究費の特別控除（個人事業者）", critical: false, tip: "中小企業技術基盤強化税制。個人事業者にも適用あり" },
    ]
  },
  {
    id: "s5", icon: "🏛️", title: "住民税・事業税", color: "#EC4899",
    items: [
      { id: "5-1", text: "住民税の申告不要選択の適否（配当・株式譲渡所得）", critical: true,  tip: "所得税と住民税で申告方法を変えられる場合の有利判定" },
      { id: "5-2", text: "個人事業税の見込み額の試算・通知", critical: false, tip: "事業所得290万円超の場合、翌年に個人事業税が発生" },
      { id: "5-3", text: "業種による事業税率の確認（5%・3%）", critical: false, tip: "業種一覧で税率を確認" },
      { id: "5-4", text: "森林環境税（令和6年〜1,000円追加）の確認", critical: false, tip: "令和6年より均等割に1,000円上乗せ" },
      { id: "5-5", text: "調整控除の計算確認（課税所得200万円以下）", critical: false, tip: "住民税の調整控除計算を確認" },
      { id: "5-6", text: "住民税に反映される付表・別表の添付", critical: true,  tip: "第二表・第四表の内容が住民税に連動していることを確認" },
      { id: "5-7", text: "事業税では青色申告特別控除が適用されないことの確認", critical: false, tip: "個人事業税の課税標準は青色控除前の事業所得" },
      { id: "5-8", text: "住民税の扶養親族の入力漏れがないか（第二表の確認）", critical: true,  tip: "所得税の扶養と住民税の扶養が一致しているか確認" },
    ]
  },
  {
    id: "s6", icon: "📎", title: "添付書類・提出方法", color: "#06B6D4",
    items: [
      { id: "6-1",  text: "源泉徴収票の添付（e-Tax:不要・書面:必須）", critical: true,  tip: "提出方法によって扱いが異なる" },
      { id: "6-2",  text: "控除証明書類の添付（e-Tax:原本保存・書面:添付）", critical: false, tip: "電子データ証明書も対応" },
      { id: "6-3",  text: "医療費明細書の作成・添付（領収書は5年保存）", critical: false, tip: "令和元年分以降は明細書で可" },
      { id: "6-4",  text: "ふるさと納税：寄附金受領証明書の添付", critical: false, tip: "ワンストップ申請書の有無も確認" },
      { id: "6-5",  text: "住宅ローン控除：残高証明書・登記事項証明書等の添付", critical: true,  tip: "初年度は書類が多い。チェックリスト作成を推奨" },
      { id: "6-6",  text: "e-Tax：送信完了・受信通知の保存", critical: true,  tip: "メッセージボックスの受信通知を必ず保存" },
      { id: "6-7",  text: "書面提出：消印・収受印の確認", critical: false, tip: "期限内提出を証明する証拠を保管" },
      { id: "6-8",  text: "申告書控えの依頼者への交付", critical: false, tip: "電子データまたは書面で依頼者へ交付" },
      { id: "6-9",  text: "マイナンバーカード等の写し添付（書面提出の場合）", critical: false, tip: "e-Taxは不要" },
      { id: "6-10", text: "海外口座・外国財産調書の要否確認（5,000万円超は提出義務）", critical: false, tip: "対象者は原則提出義務あり" },
      { id: "6-11", text: "譲渡所得関係：売買契約書・取得費証明書類の保管確認", critical: false, tip: "不動産・株式の譲渡がある場合は書類保管が必須" },
      { id: "6-12", text: "青色申告：帳簿・総勘定元帳の保存確認（7年間）", critical: false, tip: "帳簿書類の保存は青色申告の基本要件" },
    ]
  },
  {
    id: "s7", icon: "🔢", title: "数値・計算の最終確認", color: "#EF4444",
    items: [
      { id: "7-1",  text: "課税標準の計算（損益通算のルール・制限を確認）", critical: true,  tip: "不動産・株式等の損益通算制限を必ず確認" },
      { id: "7-2",  text: "所得税の税率適用が正しいか（速算表で確認）", critical: true,  tip: "課税所得に対する税率・控除額を速算表で確認" },
      { id: "7-3",  text: "復興特別所得税（2.1%）が加算されているか", critical: true,  tip: "令和19年分まで適用。忘れがちな項目" },
      { id: "7-4",  text: "予定納税額の控除計算（第1期・第2期の二重控除に注意）", critical: true,  tip: "実際の納付額と照合" },
      { id: "7-5",  text: "源泉徴収税額の合計（全源泉票を合算）", critical: true,  tip: "手入力ミスに注意" },
      { id: "7-6",  text: "納付税額または還付税額の最終確認", critical: true,  tip: "確定税額＝算出税額－税額控除－予定納税等" },
      { id: "7-7",  text: "申告書第一表と第二表の整合性確認", critical: true,  tip: "第二表の控除額が第一表に正しく転記されているか" },
      { id: "7-8",  text: "前年比±30%超の項目の理由確認", critical: false, tip: "大きな変動には必ず理由がある。依頼者に確認" },
      { id: "7-9",  text: "端数処理が正しいか（所得・控除・税額それぞれの切捨・切上）", critical: false, tip: "各段階の端数処理ルールを確認" },
      { id: "7-10", text: "修正申告・更正の請求の要否確認（過年度分）", critical: false, tip: "前年の誤りが判明した場合は対応要否を検討" },
      { id: "7-11", text: "分離課税の税額計算（株式・不動産・退職所得それぞれ）", critical: true,  tip: "分離課税の税額が総合課税の税額と合算されているか確認" },
      { id: "7-12", text: "控除しきれない所得控除の確認（繰越可否）", critical: false, tip: "雑損控除・純損失の繰越は翌年以降3年間適用可" },
    ]
  },
  {
    id: "s8", icon: "✅", title: "申告後・納付の確認", color: "#14B8A6",
    items: [
      { id: "8-1", text: "納付方法の確認（振替納税・ダイレクト納付・コンビニ等）", critical: false, tip: "振替納税：申告期限翌月中旬に引落し" },
      { id: "8-2", text: "振替納税の口座・引落日の確認と依頼者への案内", critical: true,  tip: "口座残高不足による不納付に注意" },
      { id: "8-3", text: "延納制度の案内（納付額が10万円超）", critical: false, tip: "5月末まで延納可。ただし利子税0.9%発生" },
      { id: "8-4", text: "予定納税の通知・翌年見込み税額の案内", critical: false, tip: "前年申告納税額15万円以上の場合は予定納税あり" },
      { id: "8-5", text: "申告書・添付書類の事務所保管（7年間）", critical: false, tip: "電子データも含めた保管体制を確認" },
      { id: "8-6", text: "依頼者への申告内容説明・来年に向けたアドバイス", critical: true,  tip: "「税金がいくら変わったか」「来年はこうしましょう」の一言が信頼を生む" },
      { id: "8-7", text: "節税提案のチェック（iDeCo・共済・生命保険等）", critical: false, tip: "来年に向けた節税対策を1枚レポートで提供できるとベスト" },
      { id: "8-8", text: "次回申告のための資料準備アドバイスの実施", critical: false, tip: "今年のNG・漏れをもとに来年のヒアリングシートを改訂する" },
    ]
  },
];

const STORAGE_KEY = "kakutei_checklist_v3";
const DONE_STATUSES = ["ok", "na"];
const totalItems = SECTIONS.reduce((a, s) => a + s.items.length, 0);

function loadData() {
  try { const r = localStorage.getItem(STORAGE_KEY); if (r) return JSON.parse(r); } catch (_) {}
  return null;
}
function saveData(d) { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); } catch (_) {} }

function createInitialState() {
  const checks = {};
  SECTIONS.forEach(s => s.items.forEach(i => { checks[i.id] = { status: "pending", memo: "" }; }));
  return { clientName: "", year: "6", staff: "", checks, feedback: { strength: "", growth: "", action: "" }, startedAt: new Date().toISOString() };
}

export default function App() {
  const [data, setData] = useState(() => loadData() || createInitialState());
  const [activeSection, setActiveSection] = useState(0);
  const [expandedTip, setExpandedTip] = useState(null);
  const [showReview, setShowReview] = useState(false);
  const [celebrating, setCelebrating] = useState(false);
  const [prevDone, setPrevDone] = useState(0);

  useEffect(() => { saveData(data); }, [data]);

  const okCount    = Object.values(data.checks).filter(c => c.status === "ok").length;
  const naCount    = Object.values(data.checks).filter(c => c.status === "na").length;
  const ngCount    = Object.values(data.checks).filter(c => c.status === "ng").length;
  const doneCount  = okCount + naCount;
  const pendingCount = totalItems - doneCount - ngCount;
  const progressPct  = Math.round((doneCount / totalItems) * 100);

  useEffect(() => {
    if (doneCount > prevDone && doneCount % 10 === 0) { setCelebrating(true); setTimeout(() => setCelebrating(false), 2000); }
    setPrevDone(doneCount);
  }, [doneCount]);

  const setCheck = (id, status) => setData(d => ({ ...d, checks: { ...d.checks, [id]: { ...d.checks[id], status } } }));
  const setMemo  = (id, memo)   => setData(d => ({ ...d, checks: { ...d.checks, [id]: { ...d.checks[id], memo  } } }));
  const resetAll = () => { if (confirm("全データをリセットしますか？")) { setData(createInitialState()); setActiveSection(0); } };

  const sectionProgress = SECTIONS.map(s => ({
    ok: s.items.filter(i => DONE_STATUSES.includes(data.checks[i.id]?.status)).length,
    ng: s.items.filter(i => data.checks[i.id]?.status === "ng").length,
    total: s.items.length,
  }));

  const ngItems = [];
  SECTIONS.forEach(s => s.items.forEach(i => { if (data.checks[i.id]?.status === "ng") ngItems.push({ ...i, section: s.title, sectionColor: s.color }); }));
  const isAllDone = pendingCount === 0 && ngCount === 0;

  if (showReview) return <ReviewScreen data={data} setData={setData} ngItems={ngItems} okCount={okCount} naCount={naCount} ngCount={ngCount} doneCount={doneCount} onBack={() => setShowReview(false)} />;

  return (
    <div style={{ fontFamily: "'Noto Sans JP','Hiragino Kaku Gothic ProN',sans-serif", background: "#0F172A", minHeight: "100vh", color: "#E2E8F0" }}>
      {celebrating && <Confetti />}
      <div style={{ background: "linear-gradient(135deg,#1E293B,#0F172A)", borderBottom: "1px solid #1E3A5F", padding: "16px 20px" }}>
        <div style={{ maxWidth: 960, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
            <div>
              <div style={{ fontSize: 11, color: "#64748B", letterSpacing: 2, textTransform: "uppercase", marginBottom: 2 }}>陽太税理士法人</div>
              <div style={{ fontSize: 19, fontWeight: 800, color: "#F8FAFC" }}>個人確定申告 所長チェックリスト</div>
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={resetAll} style={B("#1E293B","#475569")}>リセット</button>
              <button onClick={() => setShowReview(true)} style={B(isAllDone?"#1D4ED8":"#1E293B", isAllDone?"#3B82F6":"#475569")}>
                {isAllDone ? "🎉 最終レビュー" : "📊 レビュー"}
              </button>
            </div>
          </div>

          <div style={{ display: "flex", gap: 10, marginTop: 12, flexWrap: "wrap" }}>
            {[{ label:"クライアント名", key:"clientName", placeholder:"山田 太郎" }, { label:"令和　年分", key:"year", placeholder:"6" }, { label:"担当スタッフ", key:"staff", placeholder:"担当者名" }].map(f => (
              <div key={f.key} style={{ flex: 1, minWidth: 120 }}>
                <div style={{ fontSize: 10, color: "#94A3B8", marginBottom: 3 }}>{f.label}</div>
                <input value={data[f.key]} onChange={e => setData(d => ({ ...d, [f.key]: e.target.value }))} placeholder={f.placeholder}
                  style={{ width:"100%", background:"#1E293B", border:"1px solid #334155", borderRadius:6, padding:"6px 9px", color:"#F1F5F9", fontSize:13, outline:"none", boxSizing:"border-box" }} />
              </div>
            ))}
          </div>

          <div style={{ display:"flex", gap:12, marginTop:9, flexWrap:"wrap" }}>
            {[["#16A34A",`OK ${okCount}件`],["#0891B2",`該当なし(N/A) ${naCount}件`],["#DC2626",`NG ${ngCount}件`],["#475569",`未確認 ${pendingCount}件`]].map(([c,l]) => (
              <div key={l} style={{ display:"flex", alignItems:"center", gap:5 }}>
                <div style={{ width:9,height:9,borderRadius:2,background:c }} />
                <span style={{ fontSize:11,color:"#94A3B8" }}>{l}</span>
              </div>
            ))}
          </div>

          <div style={{ marginTop:9 }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
              <span style={{ fontSize:12,color:"#94A3B8" }}>完了 <strong style={{color:"#4ADE80"}}>{doneCount}</strong> / {totalItems}</span>
              <span style={{ fontSize:13,fontWeight:700,color:progressPct===100?"#4ADE80":"#60A5FA" }}>{progressPct}%</span>
            </div>
            <div style={{ height:7,background:"#1E293B",borderRadius:4,overflow:"hidden" }}>
              <div style={{ height:"100%",width:`${progressPct}%`,background:progressPct===100?"linear-gradient(90deg,#4ADE80,#22D3EE)":"linear-gradient(90deg,#3B82F6,#8B5CF6)",borderRadius:4,transition:"width 0.5s" }} />
            </div>
            {ngCount>0 && <div style={{ height:3,background:"#1E293B",borderRadius:4,overflow:"hidden",marginTop:3 }}><div style={{ height:"100%",width:`${(ngCount/totalItems)*100}%`,background:"#EF4444",borderRadius:4,transition:"width 0.4s" }} /></div>}
          </div>
        </div>
      </div>

      <div style={{ maxWidth:960, margin:"0 auto", padding:"18px" }}>
        <div style={{ display:"flex", gap:14 }}>
          <div style={{ width:190, flexShrink:0 }}>
            {SECTIONS.map((s,idx) => {
              const p = sectionProgress[idx]; const isA = activeSection===idx; const done = p.ok===p.total;
              return (
                <button key={s.id} onClick={() => setActiveSection(idx)} style={{ display:"block",width:"100%",textAlign:"left",padding:"9px 11px",marginBottom:3,background:isA?"#1E293B":"transparent",border:isA?`1px solid ${s.color}40`:"1px solid transparent",borderLeft:isA?`3px solid ${s.color}`:"3px solid transparent",borderRadius:8,cursor:"pointer" }}>
                  <div style={{ display:"flex",alignItems:"center",gap:5 }}>
                    <span style={{ fontSize:13 }}>{s.icon}</span>
                    <span style={{ fontSize:11,fontWeight:600,color:isA?"#F1F5F9":"#94A3B8",flex:1,lineHeight:1.3 }}>{s.title}</span>
                    {done && <span>✅</span>}
                    {p.ng>0 && <span style={{ fontSize:10,color:"#F87171",fontWeight:700 }}>NG</span>}
                  </div>
                  <div style={{ marginTop:4,height:3,background:"#1E293B",borderRadius:2 }}>
                    <div style={{ height:"100%",width:`${(p.ok/p.total)*100}%`,background:s.color,borderRadius:2,transition:"width 0.4s" }} />
                  </div>
                  <div style={{ fontSize:10,color:"#64748B",marginTop:2 }}>{p.ok}/{p.total}</div>
                </button>
              );
            })}
          </div>
          <div style={{ flex:1,minWidth:0 }}>
            <SectionPanel section={SECTIONS[activeSection]} checks={data.checks} setCheck={setCheck} setMemo={setMemo} expandedTip={expandedTip} setExpandedTip={setExpandedTip} onNext={activeSection<SECTIONS.length-1?()=>setActiveSection(activeSection+1):null} />
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionPanel({ section, checks, setCheck, setMemo, expandedTip, setExpandedTip, onNext }) {
  const okC  = section.items.filter(i => checks[i.id]?.status === "ok").length;
  const naC  = section.items.filter(i => checks[i.id]?.status === "na").length;
  const ngC  = section.items.filter(i => checks[i.id]?.status === "ng").length;
  const done = okC + naC;
  const isDone = done === section.items.length;

  return (
    <div>
      <div style={{ display:"flex",alignItems:"center",gap:10,marginBottom:13 }}>
        <span style={{ fontSize:24 }}>{section.icon}</span>
        <div>
          <div style={{ fontSize:16,fontWeight:800,color:"#F8FAFC" }}>{section.title}</div>
          <div style={{ fontSize:11,color:"#64748B" }}>OK {okC} · N/A {naC} · NG {ngC} · 未確認 {section.items.length-done-ngC}</div>
        </div>
        {isDone && <div style={{ marginLeft:"auto",background:"#14532D",border:"1px solid #16A34A",color:"#4ADE80",padding:"3px 10px",borderRadius:20,fontSize:11,fontWeight:700 }}>✅ 完了</div>}
      </div>

      {section.items.map((item, idx) => {
        const chk = checks[item.id] || { status:"pending", memo:"" };
        const isOk = chk.status==="ok", isNg=chk.status==="ng", isNa=chk.status==="na";
        const doneSt = isOk||isNa;
        const tipOpen = expandedTip===item.id;
        const bg = isNg?"#2A1215":isOk?"#0F2A1A":isNa?"#0C1F2A":"#1E293B";
        const bd = isNg?"#7F1D1D":isOk?"#14532D":isNa?"#155E75":"#334155";

        return (
          <div key={item.id} style={{ background:bg,border:`1px solid ${bd}`,borderRadius:9,marginBottom:6,overflow:"hidden",transition:"all 0.2s" }}>
            <div style={{ padding:"10px 12px" }}>
              <div style={{ display:"flex",gap:8,alignItems:"flex-start" }}>
                {/* Buttons */}
                <div style={{ display:"flex",gap:4,flexShrink:0,marginTop:1 }}>
                  <button onClick={() => setCheck(item.id, isOk?"pending":"ok")} title="OK：確認済み"
                    style={{ width:34,height:34,borderRadius:7,border:"none",cursor:"pointer",transition:"all 0.18s",background:isOk?"#16A34A":"#0F172A",color:isOk?"#fff":"#64748B",fontSize:isOk?16:12,fontWeight:700,boxShadow:isOk?"0 0 10px #16A34A55":"none",display:"flex",alignItems:"center",justifyContent:"center" }}>
                    {isOk?"✓":"OK"}
                  </button>
                  <button onClick={() => setCheck(item.id, isNg?"pending":"ng")} title="NG：問題あり"
                    style={{ width:34,height:34,borderRadius:7,border:"none",cursor:"pointer",transition:"all 0.18s",background:isNg?"#DC2626":"#0F172A",color:isNg?"#fff":"#64748B",fontSize:12,fontWeight:700,boxShadow:isNg?"0 0 10px #DC262655":"none",display:"flex",alignItems:"center",justifyContent:"center" }}>
                    NG
                  </button>
                  <button onClick={() => setCheck(item.id, isNa?"pending":"na")} title="N/A：このクライアントには該当しない項目"
                    style={{ width:34,height:34,borderRadius:7,border:"none",cursor:"pointer",transition:"all 0.18s",background:isNa?"#0E7490":"#0F172A",color:isNa?"#fff":"#64748B",fontSize:10,fontWeight:700,boxShadow:isNa?"0 0 10px #0E749055":"none",display:"flex",alignItems:"center",justifyContent:"center",lineHeight:1.2,textAlign:"center" }}>
                    N/A
                  </button>
                </div>
                {/* Content */}
                <div style={{ flex:1,minWidth:0 }}>
                  <div style={{ display:"flex",gap:5,alignItems:"flex-start" }}>
                    <div style={{ flex:1 }}>
                      <span style={{ fontSize:10,color:"#64748B",marginRight:4 }}>#{idx+1}</span>
                      {item.critical && <span style={{ fontSize:10,background:"#7C2D12",color:"#FB923C",padding:"1px 5px",borderRadius:4,marginRight:4,fontWeight:700 }}>重要</span>}
                      {isNa && <span style={{ fontSize:10,background:"#164E63",color:"#67E8F9",padding:"1px 5px",borderRadius:4,marginRight:4 }}>N/A</span>}
                      <span style={{ fontSize:13,color:isNg?"#FCA5A5":isNa?"#67E8F9":isOk?"#86EFAC":"#E2E8F0",fontWeight:500,textDecoration:doneSt?"line-through":"none",opacity:doneSt?0.65:1 }}>
                        {item.text}
                      </span>
                    </div>
                    <button onClick={() => setExpandedTip(tipOpen?null:item.id)}
                      style={{ flexShrink:0,background:"none",border:"none",color:tipOpen?"#FCD34D":"#64748B",cursor:"pointer",fontSize:14,padding:2 }}>💡</button>
                  </div>
                  {tipOpen && <div style={{ marginTop:6,padding:"7px 10px",background:"#0F172A",borderRadius:6,borderLeft:`3px solid ${section.color}`,fontSize:12,color:"#94A3B8",lineHeight:1.6 }}>{item.tip}</div>}
                  {(isNg||isNa||chk.memo?.trim()) && (
                    <input value={chk.memo} onChange={e => setMemo(item.id, e.target.value)}
                      placeholder={isNg?"NG理由・対応内容を記入...":isNa?"該当なし理由（任意）":"メモ"}
                      style={{ marginTop:6,width:"100%",background:"#0F172A",border:`1px solid ${isNg?"#7F1D1D":isNa?"#155E75":"#334155"}`,borderRadius:6,padding:"5px 9px",color:"#F1F5F9",fontSize:12,outline:"none",boxSizing:"border-box" }} />
                  )}
                  {!isNg&&!isNa&&!chk.memo?.trim()&&isOk&&(
                    <button onClick={() => setMemo(item.id," ")} style={{ background:"none",border:"none",color:"#4B5563",fontSize:11,cursor:"pointer",marginTop:3,padding:0 }}>+ メモ追加</button>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      })}

      <div style={{ display:"flex",gap:8,marginTop:11,justifyContent:"space-between",flexWrap:"wrap" }}>
        <div style={{ display:"flex",gap:7 }}>
          <button onClick={() => section.items.forEach(i => { if(checks[i.id]?.status==="pending") setCheck(i.id,"ok"); })} style={B("#14532D","#16A34A")}>未確認を全てOK</button>
          <button onClick={() => section.items.forEach(i => { if(checks[i.id]?.status==="pending") setCheck(i.id,"na"); })} style={B("#164E63","#0E7490")}>未確認を全てN/A</button>
        </div>
        {onNext && <button onClick={onNext} style={B("#1D4ED8","#3B82F6")}>次のセクション →</button>}
      </div>

      <div style={{ marginTop:9,padding:"7px 11px",background:"#0C1F2A",borderRadius:8,border:"1px solid #155E75",fontSize:11,color:"#67E8F9" }}>
        💡 <strong>N/A（該当なし）</strong>とは：このクライアントには関係のない項目（例：不動産所得がない方の不動産関連項目）に使います。N/Aも完了扱いでカウントされます。
      </div>
    </div>
  );
}

function ReviewScreen({ data, setData, ngItems, okCount, naCount, ngCount, doneCount, onBack }) {
  const allDone = ngItems.length===0 && doneCount===totalItems;
  return (
    <div style={{ fontFamily:"'Noto Sans JP','Hiragino Kaku Gothic ProN',sans-serif",background:"#0F172A",minHeight:"100vh",color:"#E2E8F0",padding:20 }}>
      <div style={{ maxWidth:800,margin:"0 auto" }}>
        <div style={{ display:"flex",alignItems:"center",gap:12,marginBottom:20 }}>
          <button onClick={onBack} style={B("#1E293B","#475569")}>← 戻る</button>
          <div style={{ fontSize:20,fontWeight:800,color:"#F8FAFC" }}>最終レビュー</div>
        </div>

        <div style={{ padding:20,borderRadius:12,marginBottom:20,background:allDone?"linear-gradient(135deg,#14532D,#166534)":ngItems.length>0?"linear-gradient(135deg,#7F1D1D,#991B1B)":"linear-gradient(135deg,#1E3A8A,#1D4ED8)",border:`1px solid ${allDone?"#16A34A":ngItems.length>0?"#DC2626":"#3B82F6"}` }}>
          <div style={{ fontSize:26,marginBottom:7 }}>{allDone?"🎉":ngItems.length>0?"⚠️":"📋"}</div>
          <div style={{ fontSize:17,fontWeight:800,color:"#F8FAFC" }}>{allDone?"申告チェック完了！全項目問題なし":ngItems.length>0?`NG ${ngItems.length}件あり。差し戻し必要`:"チェック進行中"}</div>
          <div style={{ fontSize:13,color:"#CBD5E1",marginTop:4 }}>OK {okCount} · N/A {naCount} · NG {ngCount} · 全{totalItems}項目　{data.clientName&&`　依頼者：${data.clientName}　令和${data.year}年分`}</div>
        </div>

        {ngItems.length>0 && (
          <div style={{ marginBottom:20 }}>
            <div style={{ fontSize:14,fontWeight:700,color:"#F87171",marginBottom:9 }}>⚠️ NG項目一覧（要対応）</div>
            {ngItems.map(item => (
              <div key={item.id} style={{ padding:"9px 13px",background:"#2A1215",border:"1px solid #7F1D1D",borderRadius:8,marginBottom:5 }}>
                <div style={{ fontSize:11,color:item.sectionColor,marginBottom:2 }}>{item.section}</div>
                <div style={{ fontSize:13,color:"#FCA5A5" }}>{item.text}</div>
                {data.checks[item.id]?.memo&&<div style={{ fontSize:11,color:"#94A3B8",marginTop:3 }}>📝 {data.checks[item.id].memo}</div>}
              </div>
            ))}
          </div>
        )}

        <div style={{ background:"#1E293B",border:"1px solid #334155",borderRadius:12,padding:20,marginBottom:20 }}>
          <div style={{ fontSize:14,fontWeight:700,color:"#A78BFA",marginBottom:13 }}>📝 スタッフフィードバック（所長記入）</div>
          {[{key:"strength",label:"✅ できていたこと（強み）",ph:"例：ヒアリングで家族構成の変化を的確に確認できていた"},{key:"growth",label:"🎯 成長ポイント（次回改善点）",ph:"例：医療費の対象外費用の判断精度をさらに上げよう"},{key:"action",label:"🚀 次回アクション（期限付き）",ph:"例：3/31までに医療費控除の対象外費用チェックリストを作成する"}].map(f => (
            <div key={f.key} style={{ marginBottom:13 }}>
              <div style={{ fontSize:12,color:"#94A3B8",marginBottom:5 }}>{f.label}</div>
              <textarea value={data.feedback[f.key]} onChange={e => setData(d => ({ ...d, feedback: { ...d.feedback, [f.key]:e.target.value } }))} placeholder={f.ph} rows={3}
                style={{ width:"100%",background:"#0F172A",border:"1px solid #334155",borderRadius:8,padding:"9px 12px",color:"#F1F5F9",fontSize:13,outline:"none",resize:"vertical",boxSizing:"border-box",lineHeight:1.6 }} />
            </div>
          ))}
        </div>

        <div style={{ background:"#1E293B",border:"1px solid #334155",borderRadius:12,padding:20 }}>
          <div style={{ fontSize:14,fontWeight:700,color:"#94A3B8",marginBottom:12 }}>📊 セクション別進捗</div>
          {SECTIONS.map(s => {
            const ok=s.items.filter(i=>DONE_STATUSES.includes(data.checks[i.id]?.status)).length;
            const ng=s.items.filter(i=>data.checks[i.id]?.status==="ng").length;
            const na=s.items.filter(i=>data.checks[i.id]?.status==="na").length;
            const pct=Math.round((ok/s.items.length)*100);
            return (
              <div key={s.id} style={{ marginBottom:9 }}>
                <div style={{ display:"flex",justifyContent:"space-between",marginBottom:3 }}>
                  <span style={{ fontSize:12,color:"#CBD5E1" }}>{s.icon} {s.title}</span>
                  <span style={{ fontSize:11,color:ng>0?"#F87171":ok===s.items.length?"#4ADE80":"#94A3B8" }}>{ok}/{s.items.length}{na>0?` (N/A ${na})`:""}{ng>0?` · NG ${ng}`:""}</span>
                </div>
                <div style={{ height:4,background:"#0F172A",borderRadius:2 }}>
                  <div style={{ height:"100%",width:`${pct}%`,background:ng>0?"#EF4444":s.color,borderRadius:2,transition:"width 0.5s" }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function Confetti() {
  const colors=["#4ADE80","#60A5FA","#F59E0B","#A78BFA","#F87171","#34D399","#67E8F9"];
  const p=Array.from({length:40},(_,i)=>({ id:i,color:colors[i%colors.length],left:`${Math.random()*100}%`,delay:`${Math.random()*0.8}s`,size:6+Math.random()*8 }));
  return (
    <div style={{ position:"fixed",top:0,left:0,right:0,bottom:0,pointerEvents:"none",zIndex:9999,overflow:"hidden" }}>
      <style>{`@keyframes fall{0%{transform:translateY(-20px) rotate(0deg);opacity:1}100%{transform:translateY(100vh) rotate(720deg);opacity:0}}`}</style>
      {p.map(x=>(<div key={x.id} style={{ position:"absolute",top:0,left:x.left,width:x.size,height:x.size,background:x.color,borderRadius:2,animation:`fall 2s ease-in ${x.delay} forwards` }} />))}
    </div>
  );
}

function B(bg, bd) { return { padding:"7px 13px",background:bg,border:`1px solid ${bd}`,borderRadius:7,color:"#E2E8F0",cursor:"pointer",fontSize:12,fontWeight:600 }; }
